# Copyright (c) 2013      Mellanox Technologies, Inc.
#                         All rights reserved
# $COPYRIGHT$
DIRECT_CALL_HEADER="oshmem/mca/spml/yoda/spml_yoda.h"
